#include<stdio.h>
#include<math.h>
int add(int a)
{
	int b = a + 3;
	return b;
}
int main2(int argc, char *argv[])
{
	printf("Hello Robomaster!\r\n");
	for(int i=0;i<argc;++i)
		printf("argv[%d] is: %s\n", i, *(argv + i*sizeof(char)));
	printf("Result:%d\n\r",add(10));
	fflush(stdout);
	return 0;
}
void hw1()
{
	int c=0;
	char v[10],*vv[10];
	scanf("%d",&c);
	getchar();
	scanf("%s",v);
	for(int i=0;i<10;i++)
	vv[i]=&v[i];
	main2(c,vv);
}
void hw2()
{
	int i,j;
	for(i=1;i<=9;i++)
	{
		for(j=1;j<=i;j++)
			printf("%d*%d=%d ",j*10+5,i*10+5,(j*10+5)*(i*10+5));
		printf("\n");
	}
	printf("\nscan the number of student :");
	unsigned a;
	scanf("%d",&a);
	if(a>pow(2,7))
	printf("she is a gril ,and number is %.0lf\n",a-pow(2,7));
	else
	printf("he is a boy ,and number is %d\n",a);
}
void hw3()
{
	int i,a[10];
	printf("scan 10 number\n");
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=9;i>=0;i--)
		printf("%d ",a[i]);
}
int main()
{
	int i;
	printf("Use homework :");
	scanf("%d",&i);
	switch (i)
	{
		case 1:hw1();break;
		case 2:hw2();break;
		case 3:hw3();break;
		default:break;
	}
	return 0;
}
